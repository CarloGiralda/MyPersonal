#pragma once

void controller_commerciale(void);
